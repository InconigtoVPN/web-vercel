export interface Proxy {
  proxyIP: string
  proxyPort: string
  country: string
  org: string
}

